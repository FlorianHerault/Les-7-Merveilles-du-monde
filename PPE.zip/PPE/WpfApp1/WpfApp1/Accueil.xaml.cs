﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PPe_C_tranchant_v1
{
    /// <summary>
    /// Logique d'interaction pour Accueil.xaml
    /// </summary>
    public partial class Accueil : Window
    {
        public Accueil()
        {
            InitializeComponent();
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;             //Centrer l'image au démarrage
        }
        private void cmdProfil_Click(object sender, RoutedEventArgs e)
        {
            Mon_Profil fenetre = new Mon_Profil();
            this.Close();
            fenetre.Show();
        }
        private void cmdLivre_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Donnée fenetre = new Donnée();
            this.Close();
            fenetre.Show();
        }

        private void cmdAuteur_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Donnee_Auteur fenetre = new Donnee_Auteur();
            this.Close();
            fenetre.Show();
        }

        private void cmdEmprunt_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Consultation_Emprunt fenetre = new Consultation_Emprunt();
            this.Close();
            fenetre.Show();
        }

        private void cmdEditeur_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Donnee_Editeur fenetre = new Donnee_Editeur();
            this.Close();
            fenetre.Show();
        }

        private void cmdQuit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
